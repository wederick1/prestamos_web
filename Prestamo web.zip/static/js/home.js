document.addEventListener('keydown', function(event) {
    if (event.key === 'r' || event.key === 'R') {
      window.location.href = "/login";
    }
  });
