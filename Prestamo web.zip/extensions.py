# filepath: c:\Users\Anyelis\Desktop\Datos Febr 2025\Prestamo web\extensions.py
from flask_mail import Mail

mail = Mail()